import fs from 'fs';
import path from 'path';

const android = path.resolve('android');
const javaRoot = path.join(android, 'app', 'src', 'main', 'java');
const manifestPath = path.join(android, 'app', 'src', 'main', 'AndroidManifest.xml');

function walk(dir){
  if(!fs.existsSync(dir)) return [];
  const out=[];
  for(const name of fs.readdirSync(dir)){
    const p=path.join(dir,name), st=fs.statSync(p);
    if(st.isDirectory()) out.push(...walk(p));
    else out.push(p);
  }
  return out;
}

const mainActivity = walk(javaRoot).find(p => /MainActivity\.(java|kt)$/.test(p));
if(!mainActivity) throw new Error('找不到 Capacitor MainActivity');
const ext=path.extname(mainActivity);
if(ext !== '.java') throw new Error('当前脚本需要 Java 版 MainActivity，未找到 Java MainActivity: '+mainActivity);

let main=fs.readFileSync(mainActivity,'utf8');
const pkg=(main.match(/^\s*package\s+([A-Za-z0-9_.]+)\s*;/m)||[])[1];
if(!pkg) throw new Error('无法读取 MainActivity package');
const pluginPkg=pkg+'.notifications';
const pluginDir=path.join(javaRoot,...pluginPkg.split('.'));
fs.mkdirSync(pluginDir,{recursive:true});

const plugin=`package ${pluginPkg};

import android.Manifest;
import android.app.Activity;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;

import androidx.core.app.NotificationCompat;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.annotation.Permission;
import com.getcapacitor.annotation.PermissionCallback;
import com.getcapacitor.PluginMethod;

@CapacitorPlugin(
    name = "NoirNotification",
    permissions = {
        @Permission(
            alias = "notifications",
            strings = { Manifest.permission.POST_NOTIFICATIONS }
        )
    }
)
public class NoirNotificationPlugin extends Plugin {
    private static final String CHANNEL_ID = "noir_messages";
    private static final int NOTIFICATION_PERMISSION_REQUEST = 4107;

    @Override
    public void load() {
        super.load();
        createChannel();
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return;
        NotificationManager manager = (NotificationManager) getContext().getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager == null) return;
        NotificationChannel channel = new NotificationChannel(
            CHANNEL_ID,
            "NOIR OS 消息",
            NotificationManager.IMPORTANCE_HIGH
        );
        channel.setDescription("角色新消息通知");
        channel.enableVibration(true);
        channel.setShowBadge(true);
        channel.setLockscreenVisibility(NotificationManager.IMPORTANCE_HIGH);
        manager.createNotificationChannel(channel);
    }

    @PluginMethod
    public void requestPermission(PluginCall call) {
        Activity activity = getActivity();
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) {
            JSObject ret = new JSObject();
            ret.put("granted", true);
            call.resolve(ret);
            return;
        }
        if (activity.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) {
            JSObject ret = new JSObject();
            ret.put("granted", true);
            call.resolve(ret);
            return;
        }
        requestPermissionForAlias("notifications", call, "notificationPermissionCallback");
    }

    @PermissionCallback
    private void notificationPermissionCallback(PluginCall call) {
        JSObject ret = new JSObject();
        ret.put("granted", hasPermission());
        call.resolve(ret);
    }

    private boolean hasPermission() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) return true;
        return getActivity().checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
            == PackageManager.PERMISSION_GRANTED;
    }

    @PluginMethod
    public void postNotification(PluginCall call) {
        createChannel();
        if (!hasPermission()) {
            call.reject("通知权限未开启");
            return;
        }

        String title = call.getString("title", "NOIR OS");
        String body = call.getString("body", "");
        String contactId = call.getString("contactId", "");

        Context context = getContext();
        NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager == null) {
            call.reject("系统通知服务不可用");
            return;
        }

        Intent intent = context.getPackageManager().getLaunchIntentForPackage(context.getPackageName());
        if (intent != null) {
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            if (!contactId.isEmpty()) intent.putExtra("noir_contact_id", contactId);
        }
        PendingIntent pendingIntent = intent == null ? null : PendingIntent.getActivity(
            context,
            Math.abs(contactId.hashCode()) + 97,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(new NotificationCompat.BigTextStyle().bigText(body))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setAutoCancel(true)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setShowWhen(true);

        if (pendingIntent != null) builder.setContentIntent(pendingIntent);
        manager.notify(Math.abs((title + "|" + body + "|" + System.currentTimeMillis()).hashCode()), builder.build());

        JSObject ret = new JSObject();
        ret.put("posted", true);
        call.resolve(ret);
    }
}
`;
fs.writeFileSync(path.join(pluginDir,'NoirNotificationPlugin.java'),plugin);

if(!/import\s+com\.noiros\.mobile\.notifications\.NoirNotificationPlugin;/.test(main)){
  main=main.replace(/(package\s+[A-Za-z0-9_.]+\s*;\s*)/, '$1\nimport '+pluginPkg+'.NoirNotificationPlugin;\n');
}
if(!/registerPlugin\s*\(\s*NoirNotificationPlugin\.class\s*\)/.test(main)){
  const needle='{';
  const idx=main.indexOf(needle, main.indexOf('class MainActivity'));
  if(idx<0) throw new Error('无法修改 MainActivity');
  main=main.slice(0,idx+1)+'\n        registerPlugin(NoirNotificationPlugin.class);'+main.slice(idx+1);
}
fs.writeFileSync(mainActivity,main);

let manifest=fs.readFileSync(manifestPath,'utf8');
if(!manifest.includes('android.permission.POST_NOTIFICATIONS')){
  manifest=manifest.replace(/<manifest([^>]*)>/, '<manifest$1>\n    <uses-permission android:name="android.permission.POST_NOTIFICATIONS" />');
}
fs.writeFileSync(manifestPath,manifest);

console.log('Patched Android notifications:', {mainActivity, pluginDir, manifestPath});
